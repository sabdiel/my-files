# B2T-Cohort4
Now that you all have a GitHub, you should fork and clone this repository to always be up-to-date with the class materials and assignments!!
i have received and created this file
xxxzxxxxxxxxxxx