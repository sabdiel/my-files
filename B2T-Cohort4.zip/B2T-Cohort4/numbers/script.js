var a = Number(prompt('type in a number'))
var b = Number(prompt('type in a number'))
var c = Number(prompt('type in a number'))





if(a > b && a > c){
  console.log(a + ' is the largest')
} 

if(b > a && b > c){
  console.log(b + ' is the largest')
} 

if(c > a && c > b){
  console.log(c + ' is the largest')
} 